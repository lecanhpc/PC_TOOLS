@echo off
chcp 65001 >nul
title KHOI DONG PC TOOLKIT PRO - LC_SOFT
cd /d "%~dp0"

echo ========================================================================
echo   KHOI DONG PC OPTIMIZATION TOOLKIT PRO - LC_SOFT
echo ========================================================================
echo.

set "PS_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"

if not exist "%PS_EXE%" (
    echo [X] LOI NGHAY TRONG HE DIEU HANH:
    echo     Khong tim thay PowerShell tai: %PS_EXE%
    echo     May ao hoac ban Windows nay da bi go bo PowerShell!
    echo.
    pause
    exit /b
)

"%PS_EXE%" -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0PCToolkitGUI.ps1"

if %errorlevel% neq 0 (
    echo.
    echo ========================================================================
    echo  [!] PowerShell thoat voi ma loi: %errorlevel%
    echo ========================================================================
    pause
)
