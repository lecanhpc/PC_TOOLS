using System;
using System.Diagnostics;
using System.IO;
using System.Security.Principal;
using System.Windows.Forms;

class Program {
    [STAThread]
    static void Main(string[] args) {
        string baseDir = AppDomain.CurrentDomain.BaseDirectory;
        string scriptPath = Path.Combine(baseDir, "PCToolkitGUI.ps1");
        string secPath = Path.Combine(baseDir, "ToolkitSecurity.ps1");

        // 1. Anti-Tamper: Verify existence of core modules
        if (!File.Exists(scriptPath)) {
            MessageBox.Show("LỖI BẢO MẬT: Không tìm thấy tệp mã nguồn chính (PCToolkitGUI.ps1)!\r\nPhần mềm không thể khởi động.", 
                "Lỗi Tính Toàn Vẹn - LC_SOFT", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        if (!File.Exists(secPath)) {
            MessageBox.Show("LỖI BẢO MẬT: Không tìm thấy module bảo mật (ToolkitSecurity.ps1)!\r\nVui lòng không xóa hoặc đổi tên các tệp hệ thống của LC_SOFT.", 
                "Lỗi Bản Quyền & Bảo Mật", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        // 2. Anti-Tamper & Copyright Integrity Check
        try {
            string secText = File.ReadAllText(secPath, System.Text.Encoding.UTF8);
            if (!secText.Contains("Lê Cảnh PC") || !secText.Contains("0979.298.897") || !secText.Contains("ToolkitLicenseCore")) {
                MessageBox.Show("CẢNH BÁO BẢN QUYỀN: Phát hiện tệp bảo mật đã bị thay đổi trái phép!\r\nTác quyền thuộc về Lê Cảnh PC (Hotline: 0979.298.897).\r\nỨng dụng từ chối khởi động.", 
                    "Vi Phạm Bản Quyền - LC_SOFT", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            string guiText = File.ReadAllText(scriptPath, System.Text.Encoding.UTF8);
            if (!guiText.Contains("Assert-ToolkitLicense") || !guiText.Contains("0979.298.897")) {
                MessageBox.Show("CẢNH BÁO BẢO MẬT: Phát hiện mã nguồn ứng dụng đã bị can thiệp trái phép!\r\nỨng dụng từ chối khởi động.", 
                    "Lỗi Tính Toàn Vẹn - LC_SOFT", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        } catch {}

        // 3. Tìm chính xác đường dẫn tuyệt đối của powershell.exe trên mọi hệ điều hành
        string psExe = null;
        string winDir = Environment.GetEnvironmentVariable("WINDIR") ?? @"C:\Windows";
        string sysDir = Environment.GetFolderPath(Environment.SpecialFolder.System);

        string[] candidatePaths = new string[] {
            Path.Combine(sysDir, @"WindowsPowerShell\v1.0\powershell.exe"),
            Path.Combine(winDir, @"System32\WindowsPowerShell\v1.0\powershell.exe"),
            Path.Combine(winDir, @"SysWOW64\WindowsPowerShell\v1.0\powershell.exe")
        };

        foreach (string path in candidatePaths) {
            if (File.Exists(path)) {
                psExe = path;
                break;
            }
        }

        if (string.IsNullOrEmpty(psExe)) {
            MessageBox.Show("LỖI HỆ ĐIỀU HÀNH: Không tìm thấy trình điều khiển PowerShell (powershell.exe)!\r\n\r\n" +
                "Nguyên nhân: Bản Windows hoặc Máy Ảo này đã bị lược bỏ (Lite/Ghost) thành phần PowerShell gốc của Microsoft.\r\n" +
                "Vui lòng cài đặt lại Windows PowerShell để khởi chạy công cụ.", 
                "Thiếu Thành Phần Windows - LC_SOFT", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        // 4. Check Administrator Privileges
        bool isAdmin = false;
        try {
            WindowsIdentity identity = WindowsIdentity.GetCurrent();
            if (identity != null) {
                isAdmin = new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator);
            }
        } catch {}

        ProcessStartInfo psi = new ProcessStartInfo();
        psi.FileName = psExe;
        psi.WorkingDirectory = baseDir;
        psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File \"" + scriptPath + "\"";
        psi.UseShellExecute = true;

        if (!isAdmin) {
            psi.Verb = "runas";
        }

        try {
            Process.Start(psi);
        } catch (Exception ex) {
            // Nếu người dùng bấm No/Cancel khi UAC hỏi quyền Admin
            if (ex.Message.Contains("canceled") || ex.Message.Contains("hủy")) {
                return;
            }
            MessageBox.Show("Không thể khởi động ứng dụng: " + ex.Message + "\r\nĐường dẫn PowerShell: " + psExe, 
                "Yêu Cầu Quyền Quản Trị Viên", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
