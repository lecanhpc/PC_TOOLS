using System;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Security.Principal;
using System.Diagnostics;
using System.Windows.Forms;

public class SetupForm : Form {
    private TextBox txtPath;
    private CheckBox chkDesktop;
    private CheckBox chkStartMenu;
    private CheckBox chkLaunch;
    private ProgressBar pbProgress;
    private Label lblStatus;
    private Button btnInstall;
    private Button btnBrowse;
    private string defaultInstallDir;

    public SetupForm() {
        this.Text = "Cài Đặt PC Optimization Toolkit Pro v3.5 - LC_SOFT";
        this.Size = new Size(580, 440);
        this.StartPosition = FormStartPosition.CenterScreen;
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        this.MaximizeBox = false;
        this.BackColor = Color.FromArgb(15, 23, 42); // #0F172A
        this.ForeColor = Color.FromArgb(248, 250, 252);
        this.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);

        // Try load icon
        try {
            string localIco = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ico");
            if (File.Exists(localIco)) {
                this.Icon = new Icon(localIco);
            }
        } catch {}

        defaultInstallDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "PCToolkitPro");

        InitComponents();
    }

    private void InitComponents() {
        // Top Banner Panel
        Panel pnlHeader = new Panel {
            Location = new Point(0, 0),
            Size = new Size(580, 80),
            BackColor = Color.FromArgb(30, 41, 59) // #1E293B
        };

        Label lblTitle = new Label {
            Text = "PC OPTIMIZATION TOOLKIT PRO v3.5",
            Font = new Font("Segoe UI", 13f, FontStyle.Bold),
            ForeColor = Color.FromArgb(56, 189, 248), // #38BDF8
            Location = new Point(20, 14),
            AutoSize = true
        };

        Label lblSub = new Label {
            Text = "Trình Cài Đặt 1-Click Tự Động Toàn Diện - Phát Triển Bởi LC_SOFT",
            Font = new Font("Segoe UI", 9f, FontStyle.Regular),
            ForeColor = Color.FromArgb(148, 163, 184),
            Location = new Point(22, 44),
            AutoSize = true
        };

        pnlHeader.Controls.Add(lblTitle);
        pnlHeader.Controls.Add(lblSub);
        this.Controls.Add(pnlHeader);

        // Label Path
        Label lblDir = new Label {
            Text = "Thư mục cài đặt phần mềm trên máy:",
            Location = new Point(25, 98),
            AutoSize = true,
            ForeColor = Color.FromArgb(203, 213, 225)
        };
        this.Controls.Add(lblDir);

        // Textbox Path
        txtPath = new TextBox {
            Text = defaultInstallDir,
            Location = new Point(25, 122),
            Size = new Size(415, 26),
            BackColor = Color.FromArgb(30, 41, 59),
            ForeColor = Color.White,
            BorderStyle = BorderStyle.FixedSingle
        };
        this.Controls.Add(txtPath);

        // Button Browse
        btnBrowse = new Button {
            Text = "Duyệt...",
            Location = new Point(450, 120),
            Size = new Size(95, 29),
            BackColor = Color.FromArgb(51, 65, 85),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat
        };
        btnBrowse.FlatAppearance.BorderSize = 0;
        btnBrowse.Click += (s, e) => {
            using (FolderBrowserDialog fbd = new FolderBrowserDialog()) {
                fbd.SelectedPath = txtPath.Text;
                if (fbd.ShowDialog() == DialogResult.OK) {
                    txtPath.Text = fbd.SelectedPath;
                }
            }
        };
        this.Controls.Add(btnBrowse);

        // Options Checkboxes
        chkDesktop = new CheckBox {
            Text = "Tạo biểu tượng lối tắt ngoài màn hình (Desktop Shortcut)",
            Location = new Point(28, 162),
            AutoSize = true,
            Checked = true,
            ForeColor = Color.FromArgb(226, 232, 240)
        };
        this.Controls.Add(chkDesktop);

        chkStartMenu = new CheckBox {
            Text = "Tạo biểu tượng trong menu Start của Windows",
            Location = new Point(28, 192),
            AutoSize = true,
            Checked = true,
            ForeColor = Color.FromArgb(226, 232, 240)
        };
        this.Controls.Add(chkStartMenu);

        chkLaunch = new CheckBox {
            Text = "Tự động khởi động phần mềm ngay sau khi cài đặt xong",
            Location = new Point(28, 222),
            AutoSize = true,
            Checked = true,
            ForeColor = Color.FromArgb(56, 189, 248)
        };
        this.Controls.Add(chkLaunch);

        // Progress Bar
        pbProgress = new ProgressBar {
            Location = new Point(25, 260),
            Size = new Size(520, 16),
            Style = ProgressBarStyle.Continuous,
            Value = 0
        };
        this.Controls.Add(pbProgress);

        // Status Label
        lblStatus = new Label {
            Text = "Sẵn sàng cài đặt. Nhấn 'Cài Đặt Ngay' để bắt đầu.",
            Location = new Point(25, 284),
            Size = new Size(520, 22),
            ForeColor = Color.FromArgb(148, 163, 184)
        };
        this.Controls.Add(lblStatus);

        // Install Button
        btnInstall = new Button {
            Text = "🚀 CÀI ĐẶT NGAY (1-CLICK INSTALL)",
            Location = new Point(25, 316),
            Size = new Size(520, 48),
            BackColor = Color.FromArgb(16, 185, 129), // #10B981
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 12f, FontStyle.Bold),
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand
        };
        btnInstall.FlatAppearance.BorderSize = 0;
        btnInstall.Click += BtnInstall_Click;
        this.Controls.Add(btnInstall);

        // Footer Contact
        Label lblContact = new Label {
            Text = "Hỗ trợ kỹ thuật: lecanhpc@gmail.com | Zalo/Hotline: 0979.298.897",
            Location = new Point(25, 375),
            Size = new Size(520, 20),
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 8.5f, FontStyle.Regular),
            ForeColor = Color.FromArgb(100, 116, 139)
        };
        this.Controls.Add(lblContact);
    }

    private void BtnInstall_Click(object sender, EventArgs e) {
        string targetDir = txtPath.Text.Trim();
        if (string.IsNullOrEmpty(targetDir)) {
            MessageBox.Show("Vui lòng chọn đường dẫn thư mục cài đặt hợp lệ!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        btnInstall.Enabled = false;
        btnBrowse.Enabled = false;
        txtPath.Enabled = false;
        chkDesktop.Enabled = false;
        chkStartMenu.Enabled = false;
        chkLaunch.Enabled = false;

        lblStatus.Text = "Đang giải nén bộ cài đặt vào: " + targetDir + "...";
        pbProgress.Value = 10;
        Application.DoEvents();

        try {
            if (!Directory.Exists(targetDir)) {
                Directory.CreateDirectory(targetDir);
            }

            // Extract embedded zip resource
            Assembly asm = Assembly.GetExecutingAssembly();
            string resourceName = null;
            foreach (string name in asm.GetManifestResourceNames()) {
                if (name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase)) {
                    resourceName = name;
                    break;
                }
            }

            if (string.IsNullOrEmpty(resourceName)) {
                // If not embedded as resource, look for PCToolkitPro_Full.zip in current dir
                string localZip = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PCToolkitPro_Full.zip");
                if (File.Exists(localZip)) {
                    ExtractZipFile(localZip, targetDir);
                } else {
                    throw new FileNotFoundException("Không tìm thấy gói dữ liệu bộ cài (PCToolkitPro_Full.zip)!");
                }
            } else {
                using (Stream stream = asm.GetManifestResourceStream(resourceName)) {
                    using (ZipArchive archive = new ZipArchive(stream, ZipArchiveMode.Read)) {
                        int total = archive.Entries.Count;
                        int current = 0;
                        foreach (ZipArchiveEntry entry in archive.Entries) {
                            current++;
                            string entryName = entry.FullName;
                            if (string.IsNullOrEmpty(entryName) || entryName.EndsWith("/") || entryName.EndsWith("\\")) {
                                continue;
                            }
                            string destFile = Path.Combine(targetDir, entryName);
                            string destFolder = Path.GetDirectoryName(destFile);
                            if (!Directory.Exists(destFolder)) {
                                Directory.CreateDirectory(destFolder);
                            }

                            entry.ExtractToFile(destFile, true);
                            int pct = 10 + (int)((float)current / total * 70);
                            pbProgress.Value = Math.Min(80, pct);
                            lblStatus.Text = string.Format("Đang nạp: {0} ({1}/{2})...", entry.Name, current, total);
                            Application.DoEvents();
                        }
                    }
                }
            }

            pbProgress.Value = 85;
            lblStatus.Text = "Đang tạo lối tắt ngoài Desktop và Menu Start...";
            Application.DoEvents();

            string mainExe = Path.Combine(targetDir, "PCToolkitPro.exe");
            if (!File.Exists(mainExe)) {
                mainExe = Path.Combine(targetDir, "START.bat");
            }
            string iconFile = Path.Combine(targetDir, "app.ico");

            // Create Desktop Shortcut
            if (chkDesktop.Checked) {
                try {
                    string desktopFolder = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                    if (!string.IsNullOrEmpty(desktopFolder) && Directory.Exists(desktopFolder)) {
                        string lnkPath = Path.Combine(desktopFolder, "PC Optimization Toolkit Pro.lnk");
                        CreateShortcut(lnkPath, mainExe, targetDir, iconFile, "Bộ công cụ Tối Ưu & Test Máy Toàn Diện - LC_SOFT");
                    }
                } catch {}
                try {
                    string commonDesktop = Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory);
                    if (!string.IsNullOrEmpty(commonDesktop) && Directory.Exists(commonDesktop)) {
                        string lnkPath2 = Path.Combine(commonDesktop, "PC Optimization Toolkit Pro.lnk");
                        CreateShortcut(lnkPath2, mainExe, targetDir, iconFile, "Bộ công cụ Tối Ưu & Test Máy Toàn Diện - LC_SOFT");
                    }
                } catch {}
            }

            // Create Start Menu Shortcut
            if (chkStartMenu.Checked) {
                string startMenu = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms), "PC Optimization Toolkit Pro");
                if (!Directory.Exists(startMenu)) Directory.CreateDirectory(startMenu);
                string lnkPath = Path.Combine(startMenu, "PC Optimization Toolkit Pro.lnk");
                CreateShortcut(lnkPath, mainExe, targetDir, iconFile, "Bộ công cụ Tối Ưu & Test Máy Toàn Diện - LC_SOFT");
            }

            // Create Uninstall script
            string uninstaller = Path.Combine(targetDir, "Uninstall.bat");
            string uninstContent = "@echo off\r\ntitle Go Bo PC Optimization Toolkit Pro\r\necho Dang go bo ung dung khoi may tinh...\r\ndel \"%PUBLIC%\\Desktop\\PC Optimization Toolkit Pro.lnk\" 2>nul\r\ndel \"%USERPROFILE%\\Desktop\\PC Optimization Toolkit Pro.lnk\" 2>nul\r\nrmdir /S /Q \"%ALLUSERSPROFILE%\\Microsoft\\Windows\\Start Menu\\Programs\\PC Optimization Toolkit Pro\" 2>nul\r\necho Da go bo cac loi tat Shortcut thanh cong!\r\necho Ban co the xoa thu muc nay: %~dp0\r\npause\r\n";
            File.WriteAllText(uninstaller, uninstContent);

            pbProgress.Value = 100;
            lblStatus.Text = "✅ CÀI ĐẶT THÀNH CÔNG 100%!";
            lblStatus.ForeColor = Color.FromArgb(74, 222, 128); // Green

            if (chkLaunch.Checked && File.Exists(mainExe)) {
                ProcessStartInfo psi = new ProcessStartInfo {
                    FileName = mainExe,
                    WorkingDirectory = targetDir,
                    Verb = "runas"
                };
                Process.Start(psi);
            }

            MessageBox.Show("Cài đặt PC Optimization Toolkit Pro v3.5 thành công!\r\nBiểu tượng đã được tạo ngoài màn hình Desktop.", "Hoàn Tất", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();

        } catch (Exception ex) {
            lblStatus.Text = "❌ Lỗi: " + ex.Message;
            lblStatus.ForeColor = Color.FromArgb(248, 113, 113);
            MessageBox.Show("Có lỗi xảy ra trong quá trình cài đặt:\r\n" + ex.Message, "Lỗi Cài Đặt", MessageBoxButtons.OK, MessageBoxIcon.Error);
            btnInstall.Enabled = true;
            btnBrowse.Enabled = true;
            txtPath.Enabled = true;
        }
    }

    private void ExtractZipFile(string zipPath, string targetDir) {
        using (ZipArchive archive = ZipFile.OpenRead(zipPath)) {
            int total = archive.Entries.Count;
            int current = 0;
            foreach (ZipArchiveEntry entry in archive.Entries) {
                current++;
                if (string.IsNullOrEmpty(entry.Name)) continue;
                string destFile = Path.Combine(targetDir, entry.FullName);
                string destFolder = Path.GetDirectoryName(destFile);
                if (!Directory.Exists(destFolder)) Directory.CreateDirectory(destFolder);
                entry.ExtractToFile(destFile, true);
                int pct = 10 + (int)((float)current / total * 70);
                pbProgress.Value = Math.Min(80, pct);
                Application.DoEvents();
            }
        }
    }

    private void CreateShortcut(string shortcutPath, string targetPath, string workingDir, string iconPath, string desc) {
        try {
            Type shellType = Type.GetTypeFromProgID("WScript.Shell");
            dynamic shell = Activator.CreateInstance(shellType);
            dynamic shortcut = shell.CreateShortcut(shortcutPath);
            shortcut.TargetPath = targetPath;
            shortcut.WorkingDirectory = workingDir;
            if (File.Exists(iconPath)) {
                shortcut.IconLocation = iconPath + ",0";
            }
            shortcut.Description = desc;
            shortcut.Save();
        } catch {}
    }
}

public class Program {
    [STAThread]
    public static void Main(string[] args) {
        // Auto elevate
        WindowsIdentity identity = WindowsIdentity.GetCurrent();
        WindowsPrincipal principal = new WindowsPrincipal(identity);
        if (!principal.IsInRole(WindowsBuiltInRole.Administrator)) {
            ProcessStartInfo psi = new ProcessStartInfo {
                FileName = Application.ExecutablePath,
                Verb = "runas"
            };
            try {
                Process.Start(psi);
            } catch {}
            return;
        }

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new SetupForm());
    }
}
